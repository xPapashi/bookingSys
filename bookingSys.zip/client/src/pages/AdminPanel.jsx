import { useEffect, useState } from "react";
import axios from "axios";

export default function AdminPanel() {
  const [slots, setSlots] = useState([]);

  useEffect(() => {
    const fetchSlots = async () => {
      try {
        const token = localStorage.getItem("token");
        const res = await axios.get("http://localhost:5000/api/admin/slots", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setSlots(res.data.slots);
      } catch (err) {
        console.error("Failed to load slots", err);
      }
    };

    fetchSlots();
  }, []);

  return (
    <div className="p-6 bg-[#ffedee] min-h-screen">
      <h1 className="text-2xl font-bold text-[#000200] mb-4">Admin Panel</h1>
      <ul className="bg-white p-4 rounded-xl">
        {slots.map((slot, i) => (
          <li key={i} className="border-b py-2 text-[#000200]">
            {slot.date} — {slot.times.join(", ")}
          </li>
        ))}
      </ul>
    </div>
  );
}
