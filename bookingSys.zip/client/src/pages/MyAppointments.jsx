import React from "react";

export default function MyAppointments() {
  return (
    <div className="min-h-screen bg-[#ffedee] p-6">
      <h1 className="text-2xl font-semibold text-[#000200] mb-4">
        My Appointments
      </h1>
      <p className="text-[#000200]">You don't have any appointments yet.</p>
    </div>
  );
}
