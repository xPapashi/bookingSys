// routes/admin.js
const express = require("express");
const router = express.Router();
const { protect } = require("../middleware/authMiddleware");
const { requireAdmin } = require("../middleware/adminMiddleware");

router.get("/slots", protect, requireAdmin, async (req, res) => {
  const slots = await Slot.find(); // lub Appointment.find(), zależnie od modelu
  res.json({ slots });
});

module.exports = router;
